import { Link } from "react-router-dom";
import type { Declaration } from "@/types/declaration.types";
import { DeclarationStatusBadge } from "./DeclarationStatusBadge";

export function DeclarationTable({ rows }: { rows: Declaration[] }) {
  if (rows.length === 0) {
    return <p style={{ color: "var(--muted)" }}>Kayıt yok.</p>;
  }
  return (
    <div className="table-wrap">
      <table className="data">
        <thead>
          <tr>
            <th>Durum</th>
            <th>Oluşturulma</th>
            <th>Id</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {rows.map((d) => (
            <tr key={d._id}>
              <td>
                <DeclarationStatusBadge status={d.status} />
              </td>
              <td className="mono" style={{ color: "var(--muted)" }}>
                {d.createdAt ? new Date(d.createdAt).toLocaleString("tr-TR") : "—"}
              </td>
              <td className="mono" style={{ fontSize: 12 }}>
                {d._id}
              </td>
              <td>
                <Link to={`/declarations/${d._id}`}>Aç</Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
